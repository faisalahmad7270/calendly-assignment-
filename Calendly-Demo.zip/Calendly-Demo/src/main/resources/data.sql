INSERT INTO API_CONFIG (
  system_name,
  api_url,
  http_method,
  auth_type,
  auth_token,
  response_mapping
) VALUES (
  'CALENDLY',
  'https://api.calendly.com/users/me',
  'GET',
  'Bearer',
  'eyJraWQiOiIxY2UxZTEzNjE3ZGNmNzY2YjNjZWJjY2Y4ZGM1YmFmYThhNjVlNjg0MDIzZjdjMzJiZTgzNDliMjM4MDEzNWI0IiwidHlwIjoiUEFUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiJodHRwczovL2F1dGguY2FsZW5kbHkuY29tIiwiaWF0IjoxNzY1NjkzMzgyLCJqdGkiOiIzZmI2MTRiYi00NTQwLTQ1MGYtYmVlYi1kZWMxMTE0NDMyZmYiLCJ1c2VyX3V1aWQiOiI4Yjc3NzkxMi0wODU0LTRhMjYtODc0Mi05YWFhOTI1M2ExNDQifQ.jWBeGVvafEuq4IwW6999O5icJAQ6_ko-kc0o9JZaQl4ZDxFmA_q2JIKtxrgpoQl9V-Mm8rlGF-KFDFXWOZ5gfA',
  '{"name":"resource.name","email":"resource.email"}'
);