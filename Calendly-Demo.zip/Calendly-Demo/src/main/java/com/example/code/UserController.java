package com.example.code;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    private final GenericUserFetchService service;

    public UserController(GenericUserFetchService service) {
        this.service = service;
    }

    @PostMapping("/fetch/{system}")
    public String fetchUsers(@PathVariable String system)
            throws Exception {

        service.fetchUsers(system.toUpperCase());
        return "Users fetched from " + system;
    }
}
