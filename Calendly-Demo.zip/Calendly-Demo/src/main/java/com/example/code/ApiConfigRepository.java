package com.example.code;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiConfigRepository
extends JpaRepository<ApiConfig, Long> {

ApiConfig findBySystemName(String systemName);
}
