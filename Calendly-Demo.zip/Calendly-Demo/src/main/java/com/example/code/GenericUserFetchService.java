package com.example.code;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class GenericUserFetchService {

    private final ApiConfigRepository configRepo;
    private final TempUserRepository userRepo;
    private final GenericApiClient apiClient;
    private final ResponseMapper mapper;

    public GenericUserFetchService(
            ApiConfigRepository configRepo,
            TempUserRepository userRepo,
            GenericApiClient apiClient,
            ResponseMapper mapper) {
        this.configRepo = configRepo;
        this.userRepo = userRepo;
        this.apiClient = apiClient;
        this.mapper = mapper;
    }

    public void fetchUsers(String systemName) throws Exception {

        ApiConfig config = configRepo.findBySystemName(systemName);

        String response = apiClient.callExternalApi(config);

        Map<String, String> fields =
                mapper.extractFields(
                        response,
                        config.getResponseMapping()
                );

        TempUser user = new TempUser();
        user.setName(fields.get("name"));
        user.setEmail(fields.get("email"));
        user.setSourceSystem(systemName);
        user.setFetchedAt(LocalDateTime.now());

        userRepo.save(user);
    }
}
