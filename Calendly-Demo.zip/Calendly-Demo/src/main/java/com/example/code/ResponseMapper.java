package com.example.code;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ResponseMapper {

    private final ObjectMapper mapper = new ObjectMapper();

    public Map<String, String> extractFields(
            String json,
            String mappingJson
    ) throws Exception {

        JsonNode root = mapper.readTree(json);
        Map<String, String> mapping =
                mapper.readValue(mappingJson, Map.class);

        Map<String, String> result = new HashMap<>();

        for (Map.Entry<String, String> entry : mapping.entrySet()) {
            String value = root.at(
                    "/" + entry.getValue().replace(".", "/")
            ).asText();
            result.put(entry.getKey(), value);
        }

        return result;
    }
}
