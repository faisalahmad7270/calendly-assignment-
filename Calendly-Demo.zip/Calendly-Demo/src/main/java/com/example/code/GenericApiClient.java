package com.example.code;



import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class GenericApiClient {

    private final RestTemplate restTemplate = new RestTemplate();

    public String callExternalApi(ApiConfig config) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        if (config.getAuthType() != null) {
            headers.set(
                "Authorization",
                config.getAuthType() + " " + config.getAuthToken().trim()
            );
        }

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response =
                restTemplate.exchange(
                        config.getApiUrl(),
                        HttpMethod.valueOf(config.getHttpMethod()),
                        entity,
                        String.class
                );

        return response.getBody();
    }
}
